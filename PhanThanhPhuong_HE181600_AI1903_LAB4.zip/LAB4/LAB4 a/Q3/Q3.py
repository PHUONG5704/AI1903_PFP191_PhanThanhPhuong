
try:
    with open('example.txt', 'w') as file:
        print("Empty file 'example.txt' created successfully.")
except Exception as e:
    print(f"Error creating file: {str(e)}")


#1
def seek_to_beginning(file_name):
    try:
        with open(file_name, 'r') as file:
            file.seek(0)
            
            content = file.read()
            print(f"Content from the beginning of '{file_name}':\n{content}")
    except Exception as e:
        print(f"Error reading file: {str(e)}")

seek_to_beginning('example.txt')

#2
with open('example.txt', 'r+') as file:
    file.seek(0, 2)  

    end_of_file = file.tell()

print("End of file position:", end_of_file)

#3
with open('example.txt', 'r') as file:
    first_line = file.readline()
    print("First line before seeking:", first_line)

    file.seek(2, 0)

    next_characters = file.read(1)
    print("Next 1 characters after seeking:", next_characters)
    
#4   
with open('example.txt', 'r') as file:
    file.seek(0, 2)  
    
    file.seek(0, 1) 
    
    data = file.read()
    print(data)
    
#5
with open('example.txt', 'r') as file:
    data = file.read(10)
    print('Read data:', data)

    position = file.tell()
    print('Current position:', position)
