#1
try:
    with open('sales.txt', 'w') as file:
        print("Empty file 'sales.txt' created successfully.")
except Exception as e:
    print(f"Error creating file: {str(e)}")


#2
import datetime

def create_file_with_datetime():
    try:
        current_datetime = datetime.datetime.now()
        datetime_string = current_datetime.strftime("file_2024-02-25_15-30-45.txt")
        file_name = f"file_{datetime_string}.txt"

        with open(file_name, 'w') as file:
            print(f"File '{file_name}' created successfully.")
    except Exception as e:
        print(f"Error creating file: {str(e)}")
        
create_file_with_datetime()

#3
import os

def create_file_with_permission(file_name, mode):
    try:
        with open(file_name, 'w') as file:
            os.chmod(file_name, mode)
            print(f"File '{file_name}' created successfully with permission mode {oct(mode)}.")
    except Exception as e:
        print(f"Error creating file: {str(e)}")

create_file_with_permission('example.txt', 0o644)
