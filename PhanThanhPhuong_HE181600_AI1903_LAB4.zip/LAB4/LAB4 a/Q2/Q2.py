#1
def write_to_text_file(file_name, content):
    try:
        with open(file_name, 'w') as file:
            file.write(content)
            print(f"Content has been written to '{file_name}' successfully.")
    except Exception as e:
        print(f"Error writing to file: {str(e)}")

content = "Hello, this is a sample text. Writing to a text file in Python."

write_to_text_file('output.txt', content)

#2
def append_to_file(file_name, content):
    try:
        with open(file_name, 'a') as file:
            file.write(content + '\n')  
            print(f"Content appended to '{file_name}' successfully.")
    except Exception as e:
        print(f"Error appending to file: {str(e)}")

content_to_append = "This is new content appended to the existing file."

append_to_file('existing_file.txt', content_to_append)

#3
def write_lines_to_file(file_name, lines):
    try:
        with open(file_name, 'w') as file:
            for line in lines:
                file.write(line + '\n')  
            print(f"Lines have been written to '{file_name}' successfully.")
    except Exception as e:
        print(f"Error writing to file: {str(e)}")

lines_to_write = [
    "Line 1",
    "Line 2",
    "Line 3",
    "Line 4"
]

write_lines_to_file('output.txt', lines_to_write)
