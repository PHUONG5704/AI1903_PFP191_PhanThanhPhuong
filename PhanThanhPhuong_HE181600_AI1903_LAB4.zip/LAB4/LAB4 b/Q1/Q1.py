#1
poem_content = "Mot cay lam chang nen non, ba cay chum lai thanh hon nui cao"

file_path = "poem.txt"

with open(file_path, 'w') as file:
    file.write(poem_content)

print(f"File '{file_path}' has been created with the specified content.")

def read_and_display_poem(file_path):
    try:
        with open(file_path, 'r') as file:
            for line in file:
                print(line, end='')  
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

file_path = "poem.txt"
read_and_display_poem(file_path)

print("")
print("")

#2
story_content = """A boy is playing there.
There is a playground.
An airplane is in the sky.
The sky is pink.
Alphabets and numbers are allowed in the password."""

file_path = "story.txt"

with open(file_path, 'w') as file:
    file.write(story_content)

print(f"File '{file_path}' has been created with the specified content.")

def count_lines_not_starting_with_T(file_path):
    try:
        with open(file_path, 'r') as file:
            count = 0 
            for line in file:
                if not line.strip().startswith('T'):
                    count += 1
        return count
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

file_path = "story.txt"
line_count = count_lines_not_starting_with_T(file_path)
if line_count is not None:
    print(f"Number of lines not starting with 'T' in '{file_path}': {line_count}")
    
print("")
print("")

#3 

