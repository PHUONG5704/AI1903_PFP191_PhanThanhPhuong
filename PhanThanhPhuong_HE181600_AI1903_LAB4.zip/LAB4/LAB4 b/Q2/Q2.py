#1
def count_total_words(file_path):
    try:
        with open(file_path, 'r') as file:
            content = file.read()
            words = content.split()
            total_words = len(words)
            return total_words
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

#2
def display_words_less_than_4_chars(file_path):
    try:
        with open(file_path, 'r') as file:
            for line in file:
                words = line.split()
                for word in words:
                    if len(word) < 4:
                        print(word)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: {e}")


file_path = "story.txt"

total_words = count_total_words(file_path)
if total_words is not None:
    print(f"Total number of words in '{file_path}': {total_words}")

print("Words less than 4 characters:")
display_words_less_than_4_chars(file_path)
