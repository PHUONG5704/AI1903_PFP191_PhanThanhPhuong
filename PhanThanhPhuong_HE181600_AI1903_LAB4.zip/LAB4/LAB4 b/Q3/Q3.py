#1
text_content = "Cong Hoa Xa Hoi Chu Nghia Viet Nam"

file_path = "your_text_file.txt"

with open(file_path, 'w') as file:
    file.write(text_content)

print(f"File '{file_path}' has been created with the specified content.")


def count_uppercase_characters(file_path):
    try:
        with open(file_path, 'r') as file:
            content = file.read()
            count = sum(1 for char in content if char.isupper())
            return count
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

file_path = "your_text_file.txt"

uppercase_count = count_uppercase_characters(file_path)
if uppercase_count is not None:
    print(f"Total uppercase characters in '{file_path}': {uppercase_count}")
    
print("")

#2
text_content = "this pens are mine, these pens are yours."

file_path = "article.txt"

with open(file_path, 'w') as file:
    file.write(text_content)
    
print(f"File '{file_path}' has been created with the specified content.")

def count_words_this_and_these(file_path):
    try:
        with open(file_path, 'r') as file:
            content = file.read()
            words = content.split()
            count_this = 0
            count_these = 0
            for word in words:
                if word == "this":
                    count_this += 1
                elif word == "these":
                    count_these += 1
            return count_this, count_these
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

file_path = "article.txt"

this_count, these_count = count_words_this_and_these(file_path)
if this_count is not None and these_count is not None:
    print(f"Occurrences of 'this': {this_count}")
    print(f"Occurrences of 'these': {these_count}")

