#1
text_content = "THE WORLD IS ROUND"

file_path = "matter.txt"

with open(file_path, 'w') as file:
    file.write(text_content)

print(f"File '{file_path}' has been created with the specified content.")


def hash_display(file_path):
    try:
        with open(file_path, 'r') as file:
            content = file.read().strip()
            formatted_content = '#'.join(content)
            print(formatted_content)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

file_path = "matter.txt"
hash_display(file_path)

print("")

#2
text_content = "WELL, THJS JS A WORD BY JTSELF. YOU COULD STRETCH THJS TO BE A SENTENCE"

file_path = "WORDS.TXT"

with open(file_path, 'w') as file:
    file.write(text_content)

print(f"File '{file_path}' has been created with the specified content.")

def JTOI(file_path):
    try:
        with open(file_path, 'r') as file:
            content = file.read()
            corrected_content = content.replace('J', 'I')
            print(corrected_content)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: {e}")

file_path = "WORDS.TXT"
JTOI(file_path)
